// Header.js
import React from 'react';

const Header = () => {
  return (
    <div>
     
      <h2>Contact</h2>
      <p>Phone: +358449480313</p>
      <p>Email: arnab20.dhar@gmail.com</p>
      <p>Address: Wolffintie 11 B 20/1, 65200 Vaasa</p>

      <div className='Addi'>
       <h2>Objective</h2>  
      <ul>
        <p>Seeking a part-time or full-time
            position in thefood industry and 
            cleaning sectorcan leverage my extensive
             experience and skills  gained through 
             years of restaurant work make a meaningfu
              contribution to the success of
            the establishment. 
            </p>
        </ul>
        </div>
     
    </div>
  );
}

export default Header;
