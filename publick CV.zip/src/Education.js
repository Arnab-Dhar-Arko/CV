// Education.js
import React from 'react';

const Education = () => {
  return (
    <div>
      <h2>Education</h2> 
      <div className="education-info">
        </div>
          
      <p>01/01/2021-present</p>
      <p>Program: Information Technology</p>
      <p>School: VAMK University of Applied Science</p>
      <p>Degree: Bachelor of Engineering</p>
       
      <div className='Additional'>
         
       <h2>Additional Training</h2>  
      <ul>
       
        <li>First aid course</li>
        <li>Hygiene Passport</li>
        <li>Driving License</li>
        <li>Occupational Safety Card</li>
        <li>Electrical Safety card</li>
        <li>Salmonella-certificate</li>
        
      </ul>
      </div>

      <h3>Language</h3>
      <ul>
        <li>English - Excellent</li>
        <li>Bangla - Mother language</li>
        <li>Hindi - Excellent</li>
        <li>Finnish - Basics</li>
        <li>Swedish - Basics</li>
      </ul>
    </div>
  );
}

export default Education;
