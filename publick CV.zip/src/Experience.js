// Experience.js
import React from 'react';

const Experience = () => {
  return (
    <div>
    <h2>Experience</h2>
    
    <h3>Restaurant</h3>
    <p>Year: 2022-2023</p>
    <p> company: Barona</p>
    <p>
    I Have worked in Several restaurants through this company.
  </p>
    {/* Add more details as needed */}
    
    <h3>wearhouse</h3>
    <p>Year: 2022-2023</p>
    <p>Company:sol</p>
    <p> I have worked for this company as a project developer</p>
    {/* Add more details as needed */}
    
    <h3>Food Project</h3>
    <p>Year: 2022-2023</p>
    <p>company : Salico oy</p>
    <p> a food Packaging company, and I was there as a project worker.
</p>
   
   <dev className='refer' style={{ marginLeft: '30px' }}>
    <h2> Reference</h2>
    <ul> 
    <li>Name:  Alok Biswas</li>
    <li>phone:  Alok Biswas</li>
    <li>email:  Alok Biswas</li>
    </ul>
   </dev>
  </div>
  );
}

export default Experience;
